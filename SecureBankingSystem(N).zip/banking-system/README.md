# Secure Banking Transaction System

A production-grade Spring Boot REST API implementing secure financial transactions with JWT authentication, race condition prevention, transactional integrity, and full audit logging.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | Spring Boot 3.2 |
| Security | Spring Security + JWT (JJWT 0.11.5) |
| Persistence | Spring Data JPA + Hibernate |
| Database | MySQL 8 (or PostgreSQL) |
| Cache / Locking | Redis (distributed locks) |
| Migrations | Flyway |
| API Docs | SpringDoc OpenAPI (Swagger UI) |
| Testing | JUnit 5 + Mockito + MockMvc |
| Build | Maven |

---

## Project Structure

```
secure-banking-system/
├── pom.xml
├── banking-api.postman_collection.json
└── src/
    ├── main/
    │   ├── java/com/banking/
    │   │   ├── BankingApplication.java
    │   │   ├── config/
    │   │   │   ├── AuditAspect.java          ← AOP audit logging
    │   │   │   ├── RedisConfig.java
    │   │   │   ├── SecurityConfig.java
    │   │   │   └── SwaggerConfig.java
    │   │   ├── controller/
    │   │   │   ├── AuthController.java
    │   │   │   ├── AccountController.java
    │   │   │   ├── TransactionController.java
    │   │   │   └── UserController.java
    │   │   ├── dto/
    │   │   │   ├── request/               ← validated request bodies
    │   │   │   └── response/              ← response DTOs
    │   │   ├── entity/                    ← JPA entities + enums
    │   │   ├── exception/
    │   │   │   ├── GlobalExceptionHandler.java
    │   │   │   └── *.java                 ← 7 custom exceptions
    │   │   ├── repository/                ← Spring Data JPA repositories
    │   │   ├── security/
    │   │   │   ├── JwtService.java
    │   │   │   ├── JwtAuthenticationFilter.java
    │   │   │   └── CustomUserDetailsService.java
    │   │   ├── service/
    │   │   │   ├── *.java                 ← service interfaces
    │   │   │   └── impl/                  ← service implementations
    │   │   └── util/
    │   │       ├── AccountNumberGenerator.java
    │   │       └── SecurityUtils.java
    │   └── resources/
    │       ├── application.yml
    │       ├── application-test.yml
    │       └── db/migration/
    │           └── V1__initial_schema.sql
    └── test/
        └── java/com/banking/
            ├── controller/
            │   └── AccountControllerTest.java
            └── service/
                ├── AuthServiceTest.java
                ├── AccountServiceTest.java
                └── TransactionServiceTest.java
```

---

## Prerequisites

- Java 17+
- Maven 3.9+
- MySQL 8+ or PostgreSQL 14+
- Redis 7+

---

## Setup

### 1. Database

```sql
CREATE DATABASE banking_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 2. Configure `application.yml`

Update these values:
```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/banking_db
    username: YOUR_DB_USER
    password: YOUR_DB_PASSWORD

jwt:
  secret: YOUR_256_BIT_HEX_SECRET   # openssl rand -hex 32
```

### 3. Start Redis

```bash
redis-server
```

### 4. Run

```bash
mvn spring-boot:run
```

Flyway will auto-run `V1__initial_schema.sql` on startup.

---

## API Documentation

Swagger UI: [http://localhost:8080/swagger-ui.html](http://localhost:8080/swagger-ui.html)

OpenAPI JSON: [http://localhost:8080/api-docs](http://localhost:8080/api-docs)

---

## Quick Start (Postman)

1. Import `banking-api.postman_collection.json`
2. Run **Register** → `accessToken` and `refreshToken` are auto-set as variables
3. Run **Create Savings Account** → `accountNumber` is auto-set
4. Run **Deposit**, **Withdraw**, **Transfer** using the saved variables

---

## Race Condition Prevention

Transfers use three layers of protection:

| Layer | Mechanism |
|---|---|
| Application | Redis distributed lock (10 s TTL) per account pair |
| Database | `SERIALIZABLE` transaction isolation on transfers |
| ORM | Pessimistic write lock (`SELECT … FOR UPDATE`) on accounts |
| Entity | `@Version` optimistic lock detects concurrent flushes |

Deadlocks are avoided by always acquiring account locks in canonical order (lower account number first).

---

## Key Endpoints

| Method | URL | Auth | Description |
|---|---|---|---|
| POST | `/api/v1/auth/register` | Public | Register new user |
| POST | `/api/v1/auth/login` | Public | Login, get tokens |
| POST | `/api/v1/auth/refresh-token` | Public | Refresh access token |
| POST | `/api/v1/auth/logout` | Bearer | Revoke refresh tokens |
| POST | `/api/v1/accounts` | Bearer | Create account |
| GET | `/api/v1/accounts` | Bearer | List my accounts |
| GET | `/api/v1/accounts/{number}` | Bearer | Account details |
| PATCH | `/api/v1/accounts/{number}/close` | Bearer | Close account |
| PATCH | `/api/v1/accounts/{number}/suspend` | Admin | Suspend account |
| POST | `/api/v1/transactions/transfer` | Bearer | Transfer funds |
| POST | `/api/v1/transactions/deposit` | Bearer | Deposit funds |
| POST | `/api/v1/transactions/withdraw` | Bearer | Withdraw funds |
| GET | `/api/v1/transactions/my` | Bearer | My transaction history |
| GET | `/api/v1/transactions/account/{num}` | Bearer | Account history |
| GET | `/api/v1/users/me` | Bearer | My profile |
| GET | `/api/v1/users` | Admin | All users |

---

## Running Tests

```bash
mvn test
```

Tests use H2 in-memory database and Mockito mocks — no running MySQL or Redis required.

---

## Daily Transfer Limits

| Setting | Default |
|---|---|
| Per-transfer max | ₹1,00,000 |
| Daily outgoing limit | ₹5,00,000 |

Configurable in `application.yml` under `banking.*`.
