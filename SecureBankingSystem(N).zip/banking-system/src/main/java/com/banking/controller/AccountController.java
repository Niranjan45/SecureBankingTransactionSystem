package com.banking.controller;

import com.banking.dto.request.CreateAccountRequest;
import com.banking.dto.response.AccountResponse;
import com.banking.dto.response.ApiResponse;
import com.banking.service.AccountService;
import com.banking.util.SecurityUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/accounts")
@RequiredArgsConstructor
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Accounts", description = "Create and manage bank accounts")
public class AccountController {

    private final AccountService accountService;

    @PostMapping
    @Operation(summary = "Create a new bank account")
    public ResponseEntity<ApiResponse<AccountResponse>> createAccount(
            @Valid @RequestBody CreateAccountRequest request) {
        AccountResponse response = accountService.createAccount(
                request, SecurityUtils.getCurrentUsername());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Account created successfully", response));
    }

    @GetMapping
    @Operation(summary = "Get all accounts of the logged-in user")
    public ResponseEntity<ApiResponse<List<AccountResponse>>> getMyAccounts() {
        List<AccountResponse> accounts = accountService.getUserAccounts(
                SecurityUtils.getCurrentUsername());
        return ResponseEntity.ok(ApiResponse.success(accounts));
    }

    @GetMapping("/{accountNumber}")
    @Operation(summary = "Get account details by account number")
    public ResponseEntity<ApiResponse<AccountResponse>> getAccount(
            @PathVariable String accountNumber) {
        AccountResponse response = accountService.getAccountByNumber(
                accountNumber, SecurityUtils.getCurrentUsername());
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @PatchMapping("/{accountNumber}/close")
    @Operation(summary = "Close an account")
    public ResponseEntity<ApiResponse<AccountResponse>> closeAccount(
            @PathVariable String accountNumber) {
        AccountResponse response = accountService.closeAccount(
                accountNumber, SecurityUtils.getCurrentUsername());
        return ResponseEntity.ok(ApiResponse.success("Account closed successfully", response));
    }

    @PatchMapping("/{accountNumber}/suspend")
  
    @Operation(summary = "Suspend an account")
    public ResponseEntity<ApiResponse<AccountResponse>> suspendAccount(
            @PathVariable String accountNumber) {
        AccountResponse response = accountService.suspendAccount(
                accountNumber, SecurityUtils.getCurrentUsername());
        return ResponseEntity.ok(ApiResponse.success("Account suspended successfully", response));
    }
}
