package com.banking.controller;

import com.banking.dto.request.DepositWithdrawRequest;
import com.banking.dto.request.TransferRequest;
import com.banking.dto.response.ApiResponse;
import com.banking.dto.response.TransactionResponse;
import com.banking.service.TransactionService;
import com.banking.util.SecurityUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/transactions")
@RequiredArgsConstructor
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Transactions", description = "Transfer, deposit, withdraw, and view history")
public class TransactionController {

    private final TransactionService transactionService;

    @PostMapping("/transfer")
    @Operation(summary = "Transfer funds between accounts")
    public ResponseEntity<ApiResponse<TransactionResponse>> transfer(
            @Valid @RequestBody TransferRequest request) {
        TransactionResponse response = transactionService.transfer(
                request, SecurityUtils.getCurrentUsername());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Transfer completed successfully", response));
    }

    @PostMapping("/deposit")
    @Operation(summary = "Deposit funds into an account")
    public ResponseEntity<ApiResponse<TransactionResponse>> deposit(
            @Valid @RequestBody DepositWithdrawRequest request) {
        TransactionResponse response = transactionService.deposit(
                request, SecurityUtils.getCurrentUsername());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Deposit completed successfully", response));
    }

    @PostMapping("/withdraw")
    @Operation(summary = "Withdraw funds from an account")
    public ResponseEntity<ApiResponse<TransactionResponse>> withdraw(
            @Valid @RequestBody DepositWithdrawRequest request) {
        TransactionResponse response = transactionService.withdraw(
                request, SecurityUtils.getCurrentUsername());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Withdrawal completed successfully", response));
    }

    @GetMapping("/my")
    @Operation(summary = "Get all transactions initiated by the logged-in user")
    public ResponseEntity<ApiResponse<Page<TransactionResponse>>> getMyTransactions(
            @PageableDefault(size = 20, sort = "createdAt", direction = Sort.Direction.DESC)
            Pageable pageable) {
        Page<TransactionResponse> page = transactionService.getUserTransactions(
                SecurityUtils.getCurrentUsername(), pageable);
        return ResponseEntity.ok(ApiResponse.success(page));
    }

    @GetMapping("/account/{accountNumber}")
    @Operation(summary = "Get transaction history for a specific account")
    public ResponseEntity<ApiResponse<Page<TransactionResponse>>> getAccountTransactions(
            @PathVariable String accountNumber,
            @PageableDefault(size = 20, sort = "createdAt", direction = Sort.Direction.DESC)
            Pageable pageable) {
        Page<TransactionResponse> page = transactionService.getAccountTransactions(
                accountNumber, SecurityUtils.getCurrentUsername(), pageable);
        return ResponseEntity.ok(ApiResponse.success(page));
    }

    @GetMapping("/{transactionRef}")
    @Operation(summary = "Get a transaction by reference ID")
    public ResponseEntity<ApiResponse<TransactionResponse>> getTransaction(
            @PathVariable String transactionRef) {
        TransactionResponse response = transactionService.getTransactionByRef(
                transactionRef, SecurityUtils.getCurrentUsername());
        return ResponseEntity.ok(ApiResponse.success(response));
    }
}
