package com.banking.dto.response;

import com.banking.entity.AccountStatus;
import com.banking.entity.AccountType;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
public class AccountResponse {
    private Long id;
    private String accountNumber;
    private AccountType accountType;
    private BigDecimal balance;
    private String currency;
    private AccountStatus status;
    private Long userId;
    private String ownerName;
    private LocalDateTime createdAt;
}
