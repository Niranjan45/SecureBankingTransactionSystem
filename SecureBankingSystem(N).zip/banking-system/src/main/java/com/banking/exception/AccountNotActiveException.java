package com.banking.exception;

public class AccountNotActiveException extends BankingException {
    public AccountNotActiveException(String accountNumber) {
        super("Account " + accountNumber + " is not active");
    }
}
