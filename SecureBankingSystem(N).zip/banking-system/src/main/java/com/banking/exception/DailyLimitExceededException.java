package com.banking.exception;

import java.math.BigDecimal;

public class DailyLimitExceededException extends BankingException {
    public DailyLimitExceededException(BigDecimal limit) {
        super(String.format("Daily transfer limit of %.2f exceeded", limit));
    }
}
