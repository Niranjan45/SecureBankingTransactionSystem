package com.banking.exception;

public class DuplicateResourceException extends BankingException {
    public DuplicateResourceException(String resource, String field, Object value) {
        super(String.format("%s already exists with %s: '%s'", resource, field, value));
    }
}
