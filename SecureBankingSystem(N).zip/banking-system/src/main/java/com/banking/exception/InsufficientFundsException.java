package com.banking.exception;

import java.math.BigDecimal;

public class InsufficientFundsException extends BankingException {
    public InsufficientFundsException(String accountNumber, BigDecimal available, BigDecimal required) {
        super(String.format("Insufficient funds in account %s. Available: %.2f, Required: %.2f",
                accountNumber, available, required));
    }
}
