package com.banking.exception;

public class InvalidTokenException extends BankingException {
    public InvalidTokenException(String message) { super(message); }
}
