package com.banking.repository;

import com.banking.entity.Transaction;
import com.banking.entity.TransactionStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    Optional<Transaction> findByTransactionRef(String transactionRef);

    Page<Transaction> findBySourceAccountIdOrDestinationAccountId(
            Long sourceAccountId, Long destinationAccountId, Pageable pageable);

    @Query("SELECT t FROM Transaction t WHERE " +
           "(t.sourceAccount.id = :accountId OR t.destinationAccount.id = :accountId) " +
           "AND t.createdAt BETWEEN :start AND :end")
    Page<Transaction> findByAccountIdAndDateRange(
            @Param("accountId") Long accountId,
            @Param("start") LocalDateTime start,
            @Param("end") LocalDateTime end,
            Pageable pageable);

    @Query("SELECT COALESCE(SUM(t.amount), 0) FROM Transaction t " +
           "WHERE t.sourceAccount.id = :accountId " +
           "AND t.status = 'COMPLETED' " +
           "AND t.createdAt >= :since")
    BigDecimal sumOutgoingTransactionsSince(
            @Param("accountId") Long accountId,
            @Param("since") LocalDateTime since);

    Page<Transaction> findByInitiatedById(Long userId, Pageable pageable);

    Page<Transaction> findByStatus(TransactionStatus status, Pageable pageable);
}
