
package com.banking.service;

import com.banking.dto.request.CreateAccountRequest;
import com.banking.dto.response.AccountResponse;

import java.util.List;

public interface AccountService {
    AccountResponse createAccount(CreateAccountRequest request, String username);
    AccountResponse getAccountByNumber(String accountNumber, String username);
    List<AccountResponse> getUserAccounts(String username);
    AccountResponse suspendAccount(String accountNumber, String adminUsername);
    AccountResponse closeAccount(String accountNumber, String username);
}
