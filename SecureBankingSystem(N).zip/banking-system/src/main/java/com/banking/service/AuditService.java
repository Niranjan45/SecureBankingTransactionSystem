package com.banking.service;

import com.banking.entity.AuditLog;

public interface AuditService {
    void log(String action, String entityType, String entityId,
             String performedBy, String ipAddress,
             String requestData, String responseData,
             String status, String errorMessage);
}
