package com.banking.service;

import com.banking.dto.request.DepositWithdrawRequest;
import com.banking.dto.request.TransferRequest;
import com.banking.dto.response.TransactionResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface TransactionService {
    TransactionResponse transfer(TransferRequest request, String username);
    TransactionResponse deposit(DepositWithdrawRequest request, String username);
    TransactionResponse withdraw(DepositWithdrawRequest request, String username);
    Page<TransactionResponse> getAccountTransactions(String accountNumber, String username, Pageable pageable);
    Page<TransactionResponse> getUserTransactions(String username, Pageable pageable);
    TransactionResponse getTransactionByRef(String transactionRef, String username);
}
