package com.banking.service;

import com.banking.dto.response.UserResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface UserService {
    UserResponse getUserProfile(String username);
    Page<UserResponse> getAllUsers(Pageable pageable);
    UserResponse getUserById(Long id);
}
