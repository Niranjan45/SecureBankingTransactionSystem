package com.banking.service.impl;

import com.banking.dto.request.CreateAccountRequest;
import com.banking.dto.response.AccountResponse;
import com.banking.entity.*;
import com.banking.exception.ResourceNotFoundException;
import com.banking.exception.UnauthorizedAccessException;
import com.banking.repository.AccountRepository;
import com.banking.repository.UserRepository;
import com.banking.service.AccountService;
import com.banking.util.AccountNumberGenerator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;
    private final UserRepository userRepository;
    private final AccountNumberGenerator accountNumberGenerator;

    @Override
    @Transactional
    public AccountResponse createAccount(CreateAccountRequest request, String username) {
        User user = findUserByUsername(username);

        String accountNumber = accountNumberGenerator.generate();

        Account account = Account.builder()
                .accountNumber(accountNumber)
                .accountType(request.getAccountType())
                .balance(request.getInitialDeposit())
                .currency(request.getCurrency())
                .status(AccountStatus.ACTIVE)
                .user(user)
                .build();

        account = accountRepository.save(account);
        log.info("Account created: {} for user: {}", accountNumber, username);
        return mapToResponse(account);
    }

    @Override
    @Transactional(readOnly = true)
    public AccountResponse getAccountByNumber(String accountNumber, String username) {
        Account account = findAccountByNumber(accountNumber);
        validateAccountOwnership(account, username);
        return mapToResponse(account);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AccountResponse> getUserAccounts(String username) {
        User user = findUserByUsername(username);
        return accountRepository.findByUserId(user.getId())
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public AccountResponse suspendAccount(String accountNumber, String adminUsername) {
        Account account = findAccountByNumber(accountNumber);
        account.setStatus(AccountStatus.SUSPENDED);
        account = accountRepository.save(account);
        log.info("Account {} suspended by admin: {}", accountNumber, adminUsername);
        return mapToResponse(account);
    }

    @Override
    @Transactional
    public AccountResponse closeAccount(String accountNumber, String username) {
        Account account = findAccountByNumber(accountNumber);
        validateAccountOwnership(account, username);
        account.setStatus(AccountStatus.CLOSED);
        account = accountRepository.save(account);
        log.info("Account {} closed by user: {}", accountNumber, username);
        return mapToResponse(account);
    }

    private User findUserByUsername(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User", "username", username));
    }

    private Account findAccountByNumber(String accountNumber) {
        return accountRepository.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new ResourceNotFoundException("Account", "accountNumber", accountNumber));
    }

    private void validateAccountOwnership(Account account, String username) {
        if (!account.getUser().getUsername().equals(username) &&
            !account.getUser().getRole().equals(Role.ROLE_ADMIN)) {
            throw new UnauthorizedAccessException("You do not have access to this account");
        }
    }

    public AccountResponse mapToResponse(Account account) {
        return AccountResponse.builder()
                .id(account.getId())
                .accountNumber(account.getAccountNumber())
                .accountType(account.getAccountType())
                .balance(account.getBalance())
                .currency(account.getCurrency())
                .status(account.getStatus())
                .userId(account.getUser().getId())
                .ownerName(account.getUser().getFullName())
                .createdAt(account.getCreatedAt())
                .build();
    }
}
