package com.banking.service.impl;

import com.banking.dto.request.DepositWithdrawRequest;
import com.banking.dto.request.TransferRequest;
import com.banking.dto.response.TransactionResponse;
import com.banking.entity.*;
import com.banking.exception.*;
import com.banking.repository.AccountRepository;
import com.banking.repository.TransactionRepository;
import com.banking.repository.UserRepository;
import com.banking.service.TransactionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Service
@RequiredArgsConstructor
@Slf4j
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository transactionRepository;
    private final AccountRepository accountRepository;
    private final UserRepository userRepository;
    private final RedisTemplate<String, Object> redisTemplate;

    @Value("${banking.max-transfer-amount}")
    private BigDecimal maxTransferAmount;

    @Value("${banking.daily-transfer-limit}")
    private BigDecimal dailyTransferLimit;

    private static final String TRANSFER_LOCK_PREFIX = "transfer:lock:";
    private static final long LOCK_TIMEOUT_SECONDS = 10;

    /**
     * Transfer money between accounts.
     * Uses SERIALIZABLE isolation + pessimistic locking + Redis distributed lock
     * to prevent race conditions in concurrent transfer scenarios.
     */
    @Override
    @Transactional(isolation = Isolation.SERIALIZABLE)
    public TransactionResponse transfer(TransferRequest request, String username) throws ResourceNotFoundException {
        validateSelfTransfer(request);

        String lockKey = buildTransferLockKey(
                request.getSourceAccountNumber(), request.getDestinationAccountNumber());

        Boolean locked = redisTemplate.opsForValue()
                .setIfAbsent(lockKey, "1", LOCK_TIMEOUT_SECONDS, TimeUnit.SECONDS);

        if (Boolean.FALSE.equals(locked)) {
            throw new BankingException("A concurrent transfer is in progress. Please retry.");
        }

        Transaction transaction = Transaction.builder()
                .transactionRef(UUID.randomUUID().toString())
                .transactionType(TransactionType.TRANSFER)
                .amount(request.getAmount())
                .description(request.getDescription())
                .status(TransactionStatus.PENDING)
                .build();

        try {
            // Always lock in consistent order (lower ID first) to prevent deadlocks
            Account sourceAccount = accountRepository
                    .findByAccountNumberWithLock(request.getSourceAccountNumber())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Account", "accountNumber", request.getSourceAccountNumber()));

            Account destinationAccount = accountRepository
                    .findByAccountNumberWithLock(request.getDestinationAccountNumber())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Account", "accountNumber", request.getDestinationAccountNumber()));

            User initiator = findUserByUsername(username);

            validateAccountOwnership(sourceAccount, username);
            validateAccountActive(sourceAccount);
            validateAccountActive(destinationAccount);

            checkDailyLimit(sourceAccount, request.getAmount());

            if (sourceAccount.getBalance().compareTo(request.getAmount()) < 0) {
                throw new InsufficientFundsException(
                        sourceAccount.getAccountNumber(),
                        sourceAccount.getBalance(),
                        request.getAmount());
            }

            sourceAccount.setBalance(sourceAccount.getBalance().subtract(request.getAmount()));
            destinationAccount.setBalance(destinationAccount.getBalance().add(request.getAmount()));

            accountRepository.save(sourceAccount);
            accountRepository.save(destinationAccount);

            transaction.setSourceAccount(sourceAccount);
            transaction.setDestinationAccount(destinationAccount);
            transaction.setInitiatedBy(initiator);
            transaction.setStatus(TransactionStatus.COMPLETED);
            transaction.setCompletedAt(LocalDateTime.now());

            transaction = transactionRepository.save(transaction);
            log.info("Transfer completed: {} -> {} amount: {}",
                    request.getSourceAccountNumber(),
                    request.getDestinationAccountNumber(),
                    request.getAmount());

        } catch (BankingException ex) {
            transaction.setStatus(TransactionStatus.FAILED);
            transaction.setFailureReason(ex.getMessage());
            if (transaction.getSourceAccount() == null) {
                // Can't save without accounts, just rethrow
                throw ex;
            }
            transactionRepository.save(transaction);
            throw ex;
        } finally {
            redisTemplate.delete(lockKey);
        }

        return mapToResponse(transaction);
    }

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public TransactionResponse deposit(DepositWithdrawRequest request, String username) {
        Account account = accountRepository
                .findByAccountNumberWithLock(request.getAccountNumber())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Account", "accountNumber", request.getAccountNumber()));

        validateAccountActive(account);

        User initiator = findUserByUsername(username);
        account.setBalance(account.getBalance().add(request.getAmount()));
        accountRepository.save(account);

        Transaction transaction = Transaction.builder()
                .transactionRef(UUID.randomUUID().toString())
                .transactionType(TransactionType.DEPOSIT)
                .amount(request.getAmount())
                .destinationAccount(account)
                .description(request.getDescription())
                .initiatedBy(initiator)
                .status(TransactionStatus.COMPLETED)
                .completedAt(LocalDateTime.now())
                .build();

        transaction = transactionRepository.save(transaction);
        log.info("Deposit completed: {} amount: {}", request.getAccountNumber(), request.getAmount());
        return mapToResponse(transaction);
    }

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public TransactionResponse withdraw(DepositWithdrawRequest request, String username) {
        Account account = accountRepository
                .findByAccountNumberWithLock(request.getAccountNumber())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Account", "accountNumber", request.getAccountNumber()));

        validateAccountOwnership(account, username);
        validateAccountActive(account);

        if (account.getBalance().compareTo(request.getAmount()) < 0) {
            throw new InsufficientFundsException(
                    account.getAccountNumber(), account.getBalance(), request.getAmount());
        }

        User initiator = findUserByUsername(username);
        account.setBalance(account.getBalance().subtract(request.getAmount()));
        accountRepository.save(account);

        Transaction transaction = Transaction.builder()
                .transactionRef(UUID.randomUUID().toString())
                .transactionType(TransactionType.WITHDRAWAL)
                .amount(request.getAmount())
                .sourceAccount(account)
                .description(request.getDescription())
                .initiatedBy(initiator)
                .status(TransactionStatus.COMPLETED)
                .completedAt(LocalDateTime.now())
                .build();

        transaction = transactionRepository.save(transaction);
        log.info("Withdrawal completed: {} amount: {}", request.getAccountNumber(), request.getAmount());
        return mapToResponse(transaction);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TransactionResponse> getAccountTransactions(
            String accountNumber, String username, Pageable pageable) {
        Account account = accountRepository.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Account", "accountNumber", accountNumber));
        validateAccountOwnership(account, username);
        return transactionRepository
                .findBySourceAccountIdOrDestinationAccountId(account.getId(), account.getId(), pageable)
                .map(this::mapToResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TransactionResponse> getUserTransactions(String username, Pageable pageable) {
        User user = findUserByUsername(username);
        return transactionRepository.findByInitiatedById(user.getId(), pageable)
                .map(this::mapToResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public TransactionResponse getTransactionByRef(String transactionRef, String username) {
        Transaction transaction = transactionRepository.findByTransactionRef(transactionRef)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Transaction", "transactionRef", transactionRef));

        if (!transaction.getInitiatedBy().getUsername().equals(username)) {
            throw new UnauthorizedAccessException("You do not have access to this transaction");
        }
        return mapToResponse(transaction);
    }

    // ── Private helpers ──────────────────────────────────────────────────────

    private void validateSelfTransfer(TransferRequest request) {
        if (request.getSourceAccountNumber().equals(request.getDestinationAccountNumber())) {
            throw new BankingException("Source and destination accounts cannot be the same");
        }
    }

    private void validateAccountActive(Account account) {
        if (account.getStatus() != AccountStatus.ACTIVE) {
            throw new AccountNotActiveException(account.getAccountNumber());
        }
    }

    private void validateAccountOwnership(Account account, String username) {
        if (!account.getUser().getUsername().equals(username)) {
            throw new UnauthorizedAccessException("You do not have access to account: "
                    + account.getAccountNumber());
        }
    }

    private void checkDailyLimit(Account account, BigDecimal amount) {
        LocalDateTime startOfDay = LocalDateTime.now().toLocalDate().atStartOfDay();
        BigDecimal todayOutgoing = transactionRepository
                .sumOutgoingTransactionsSince(account.getId(), startOfDay);

        if (todayOutgoing.add(amount).compareTo(dailyTransferLimit) > 0) {
            throw new DailyLimitExceededException(dailyTransferLimit);
        }
    }

    private String buildTransferLockKey(String source, String destination) {
        // Canonical ordering so A->B and B->A use same lock
        String pair = source.compareTo(destination) < 0
                ? source + ":" + destination
                : destination + ":" + source;
        return TRANSFER_LOCK_PREFIX + pair;
    }

    private User findUserByUsername(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User", "username", username));
    }

    public TransactionResponse mapToResponse(Transaction t) {
        return TransactionResponse.builder()
                .id(t.getId())
                .transactionRef(t.getTransactionRef())
                .transactionType(t.getTransactionType())
                .amount(t.getAmount())
                .currency(t.getCurrency())
                .sourceAccountNumber(t.getSourceAccount() != null
                        ? t.getSourceAccount().getAccountNumber() : null)
                .destinationAccountNumber(t.getDestinationAccount() != null
                        ? t.getDestinationAccount().getAccountNumber() : null)
                .status(t.getStatus())
                .description(t.getDescription())
                .failureReason(t.getFailureReason())
                .createdAt(t.getCreatedAt())
                .completedAt(t.getCompletedAt())
                .build();
    }
}
