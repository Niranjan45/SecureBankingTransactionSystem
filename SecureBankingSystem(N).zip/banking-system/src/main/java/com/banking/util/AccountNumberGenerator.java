package com.banking.util;

import com.banking.repository.AccountRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.security.SecureRandom;

@Component
@RequiredArgsConstructor
public class AccountNumberGenerator {

    private static final String PREFIX = "BNK";
    private static final SecureRandom RANDOM = new SecureRandom();
    private final AccountRepository accountRepository;

    /**
     * Generates a unique account number of the format: BNK + 12 digits.
     * Retries up to 5 times on collision (astronomically rare).
     */
    public String generate() {
        for (int attempt = 0; attempt < 5; attempt++) {
            String candidate = PREFIX + String.format("%012d",
                    (long) (RANDOM.nextDouble() * 1_000_000_000_000L));
            if (!accountRepository.existsByAccountNumber(candidate)) {
                return candidate;
            }
        }
        throw new IllegalStateException("Could not generate a unique account number after 5 attempts");
    }
}
