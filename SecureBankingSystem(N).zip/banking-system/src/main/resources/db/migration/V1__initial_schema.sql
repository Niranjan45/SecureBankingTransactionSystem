-- ============================================================
-- Secure Banking System - Database Schema
-- ============================================================

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id              BIGINT          AUTO_INCREMENT PRIMARY KEY,
    username        VARCHAR(50)     NOT NULL UNIQUE,
    email           VARCHAR(100)    NOT NULL UNIQUE,
    password        VARCHAR(255)    NOT NULL,
    full_name       VARCHAR(100)    NOT NULL,
    phone_number    VARCHAR(20),
    role            VARCHAR(20)     NOT NULL DEFAULT 'ROLE_USER',
    enabled         BOOLEAN         NOT NULL DEFAULT TRUE,
    locked          BOOLEAN         NOT NULL DEFAULT FALSE,
    created_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Accounts table
CREATE TABLE IF NOT EXISTS accounts (
    id              BIGINT          AUTO_INCREMENT PRIMARY KEY,
    account_number  VARCHAR(20)     NOT NULL UNIQUE,
    account_type    VARCHAR(20)     NOT NULL,  -- SAVINGS, CHECKING
    balance         DECIMAL(19, 4)  NOT NULL DEFAULT 0.0000,
    currency        VARCHAR(3)      NOT NULL DEFAULT 'INR',
    status          VARCHAR(20)     NOT NULL DEFAULT 'ACTIVE', -- ACTIVE, SUSPENDED, CLOSED
    user_id         BIGINT          NOT NULL,
    version         BIGINT          NOT NULL DEFAULT 0,  -- Optimistic locking
    created_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_accounts_user FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Transactions table
CREATE TABLE IF NOT EXISTS transactions (
    id                      BIGINT          AUTO_INCREMENT PRIMARY KEY,
    transaction_ref         VARCHAR(36)     NOT NULL UNIQUE,  -- UUID
    transaction_type        VARCHAR(20)     NOT NULL,  -- TRANSFER, DEPOSIT, WITHDRAWAL
    amount                  DECIMAL(19, 4)  NOT NULL,
    currency                VARCHAR(3)      NOT NULL DEFAULT 'INR',
    source_account_id       BIGINT,
    destination_account_id  BIGINT,
    status                  VARCHAR(20)     NOT NULL DEFAULT 'PENDING', -- PENDING, COMPLETED, FAILED, REVERSED
    description             VARCHAR(255),
    failure_reason          VARCHAR(500),
    initiated_by            BIGINT          NOT NULL,
    created_at              TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at            TIMESTAMP,
    CONSTRAINT fk_txn_source      FOREIGN KEY (source_account_id)      REFERENCES accounts(id),
    CONSTRAINT fk_txn_destination FOREIGN KEY (destination_account_id) REFERENCES accounts(id),
    CONSTRAINT fk_txn_user        FOREIGN KEY (initiated_by)           REFERENCES users(id)
);

-- Audit logs table
CREATE TABLE IF NOT EXISTS audit_logs (
    id              BIGINT          AUTO_INCREMENT PRIMARY KEY,
    action          VARCHAR(100)    NOT NULL,
    entity_type     VARCHAR(50)     NOT NULL,
    entity_id       VARCHAR(50),
    performed_by    VARCHAR(100),
    ip_address      VARCHAR(45),
    request_data    TEXT,
    response_data   TEXT,
    status          VARCHAR(20)     NOT NULL,  -- SUCCESS, FAILURE
    error_message   TEXT,
    created_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Refresh tokens table
CREATE TABLE IF NOT EXISTS refresh_tokens (
    id          BIGINT       AUTO_INCREMENT PRIMARY KEY,
    token       VARCHAR(512) NOT NULL UNIQUE,
    user_id     BIGINT       NOT NULL,
    expiry_date TIMESTAMP    NOT NULL,
    revoked     BOOLEAN      NOT NULL DEFAULT FALSE,
    CONSTRAINT fk_refresh_user FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Indexes
CREATE INDEX idx_accounts_user_id         ON accounts(user_id);
CREATE INDEX idx_accounts_account_number  ON accounts(account_number);
CREATE INDEX idx_transactions_source      ON transactions(source_account_id);
CREATE INDEX idx_transactions_destination ON transactions(destination_account_id);
CREATE INDEX idx_transactions_ref         ON transactions(transaction_ref);
CREATE INDEX idx_audit_entity             ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_performed_by       ON audit_logs(performed_by);
