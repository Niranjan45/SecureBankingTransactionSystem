package com.banking.controller;

import com.banking.dto.request.CreateAccountRequest;
import com.banking.dto.response.AccountResponse;
import com.banking.entity.AccountStatus;
import com.banking.entity.AccountType;
import com.banking.service.AccountService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AccountController.class)
@DisplayName("AccountController Integration Tests")
class AccountControllerTest {

    @Autowired private MockMvc mockMvc;
    @Autowired private ObjectMapper objectMapper;
    @MockBean  private AccountService accountService;

    private AccountResponse sampleAccount;

    @BeforeEach
    void setUp() {
        sampleAccount = AccountResponse.builder()
                .id(1L)
                .accountNumber("BNK000000000001")
                .accountType(AccountType.SAVINGS)
                .balance(new BigDecimal("5000.00"))
                .currency("INR")
                .status(AccountStatus.ACTIVE)
                .userId(1L)
                .ownerName("Test User")
                .createdAt(LocalDateTime.now())
                .build();
    }

    @Test
    @WithMockUser(username = "testuser", roles = "USER")
    @DisplayName("POST /api/v1/accounts – creates account and returns 201")
    void createAccount_returns201() throws Exception {
        CreateAccountRequest request = new CreateAccountRequest();
        request.setAccountType(AccountType.SAVINGS);
        request.setInitialDeposit(new BigDecimal("5000.00"));

        when(accountService.createAccount(any(CreateAccountRequest.class), eq("testuser")))
                .thenReturn(sampleAccount);

        mockMvc.perform(post("/api/v1/accounts")
                        .with(csrf())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.accountNumber").value("BNK000000000001"))
                .andExpect(jsonPath("$.data.balance").value(5000.00))
                .andExpect(jsonPath("$.data.accountType").value("SAVINGS"));
    }

    @Test
    @WithMockUser(username = "testuser", roles = "USER")
    @DisplayName("GET /api/v1/accounts – returns list of user accounts")
    void getMyAccounts_returnsList() throws Exception {
        when(accountService.getUserAccounts("testuser")).thenReturn(List.of(sampleAccount));

        mockMvc.perform(get("/api/v1/accounts"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data[0].accountNumber").value("BNK000000000001"));
    }

    @Test
    @WithMockUser(username = "testuser", roles = "USER")
    @DisplayName("GET /api/v1/accounts/{number} – returns specific account")
    void getAccount_returnsAccount() throws Exception {
        when(accountService.getAccountByNumber("BNK000000000001", "testuser"))
                .thenReturn(sampleAccount);

        mockMvc.perform(get("/api/v1/accounts/BNK000000000001"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.accountNumber").value("BNK000000000001"))
                .andExpect(jsonPath("$.data.status").value("ACTIVE"));
    }

    @Test
    @DisplayName("POST /api/v1/accounts – returns 403 when unauthenticated")
    void createAccount_unauthenticated_returns403() throws Exception {
        CreateAccountRequest request = new CreateAccountRequest();
        request.setAccountType(AccountType.SAVINGS);

        mockMvc.perform(post("/api/v1/accounts")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isForbidden());
    }

    @Test
    @WithMockUser(username = "testuser", roles = "USER")
    @DisplayName("POST /api/v1/accounts – returns 400 when accountType missing")
    void createAccount_missingAccountType_returns400() throws Exception {
        // Empty body – accountType is @NotNull
        mockMvc.perform(post("/api/v1/accounts")
                        .with(csrf())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false));
    }

    @Test
    @WithMockUser(username = "admin", roles = "ADMIN")
    @DisplayName("PATCH /api/v1/accounts/{number}/suspend – admin can suspend account")
    void suspendAccount_admin_returns200() throws Exception {
        AccountResponse suspended = AccountResponse.builder()
                .id(1L).accountNumber("BNK000000000001")
                .status(AccountStatus.SUSPENDED).build();

        when(accountService.suspendAccount("BNK000000000001", "admin"))
                .thenReturn(suspended);

        mockMvc.perform(patch("/api/v1/accounts/BNK000000000001/suspend")
                        .with(csrf()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("SUSPENDED"));
    }

    @Test
    @WithMockUser(username = "testuser", roles = "USER")
    @DisplayName("PATCH /api/v1/accounts/{number}/suspend – user gets 403")
    void suspendAccount_user_returns403() throws Exception {
        mockMvc.perform(patch("/api/v1/accounts/BNK000000000001/suspend")
                        .with(csrf()))
                .andExpect(status().isForbidden());
    }
}
