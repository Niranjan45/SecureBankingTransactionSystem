package com.banking.service;

import com.banking.dto.request.CreateAccountRequest;
import com.banking.dto.response.AccountResponse;
import com.banking.entity.*;
import com.banking.exception.ResourceNotFoundException;
import com.banking.exception.UnauthorizedAccessException;
import com.banking.repository.AccountRepository;
import com.banking.repository.UserRepository;
import com.banking.service.impl.AccountServiceImpl;
import com.banking.util.AccountNumberGenerator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("AccountService Unit Tests")
class AccountServiceTest {

    @Mock private AccountRepository accountRepository;
    @Mock private UserRepository userRepository;
    @Mock private AccountNumberGenerator accountNumberGenerator;

    @InjectMocks
    private AccountServiceImpl accountService;

    private User user;
    private Account account;

    @BeforeEach
    void setUp() {
        user = User.builder()
                .id(1L).username("testuser")
                .email("test@example.com").password("pass")
                .fullName("Test User").role(Role.ROLE_USER)
                .enabled(true).build();

        account = Account.builder()
                .id(1L).accountNumber("BNK000000000001")
                .accountType(AccountType.SAVINGS)
                .balance(new BigDecimal("5000.00"))
                .currency("INR").status(AccountStatus.ACTIVE)
                .user(user).version(0L).build();
    }

    @Test
    @DisplayName("createAccount: generates account number and saves")
    void createAccount_success() {
        CreateAccountRequest request = new CreateAccountRequest();
        request.setAccountType(AccountType.SAVINGS);
        request.setInitialDeposit(new BigDecimal("1000.00"));

        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));
        when(accountNumberGenerator.generate()).thenReturn("BNK000000000001");
        when(accountRepository.save(any(Account.class))).thenReturn(account);

        AccountResponse response = accountService.createAccount(request, "testuser");

        assertThat(response.getAccountNumber()).isEqualTo("BNK000000000001");
        assertThat(response.getAccountType()).isEqualTo(AccountType.SAVINGS);
        verify(accountRepository).save(any(Account.class));
    }

    @Test
    @DisplayName("createAccount: throws ResourceNotFoundException for unknown user")
    void createAccount_userNotFound() {
        when(userRepository.findByUsername("ghost")).thenReturn(Optional.empty());

        assertThatThrownBy(() ->
                accountService.createAccount(new CreateAccountRequest(), "ghost"))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    @DisplayName("getAccountByNumber: returns account for owner")
    void getAccount_ownerCanAccess() {
        when(accountRepository.findByAccountNumber("BNK000000000001"))
                .thenReturn(Optional.of(account));

        AccountResponse response = accountService.getAccountByNumber(
                "BNK000000000001", "testuser");

        assertThat(response.getAccountNumber()).isEqualTo("BNK000000000001");
    }

    @Test
    @DisplayName("getAccountByNumber: throws UnauthorizedAccessException for different user")
    void getAccount_otherUser_throwsUnauthorized() {
        User other = User.builder().id(2L).username("other")
                .role(Role.ROLE_USER).build();
        account.setUser(user); // belongs to testuser

        when(accountRepository.findByAccountNumber("BNK000000000001"))
                .thenReturn(Optional.of(account));

        assertThatThrownBy(() ->
                accountService.getAccountByNumber("BNK000000000001", "other"))
                .isInstanceOf(UnauthorizedAccessException.class);
    }

    @Test
    @DisplayName("getUserAccounts: returns all accounts for user")
    void getUserAccounts_returnsList() {
        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));
        when(accountRepository.findByUserId(1L)).thenReturn(List.of(account));

        List<AccountResponse> accounts = accountService.getUserAccounts("testuser");

        assertThat(accounts).hasSize(1);
        assertThat(accounts.get(0).getAccountNumber()).isEqualTo("BNK000000000001");
    }

    @Test
    @DisplayName("closeAccount: sets status to CLOSED")
    void closeAccount_success() {
        when(accountRepository.findByAccountNumber("BNK000000000001"))
                .thenReturn(Optional.of(account));
        when(accountRepository.save(any(Account.class))).thenAnswer(i -> {
            Account a = i.getArgument(0);
            return a;
        });

        AccountResponse response = accountService.closeAccount("BNK000000000001", "testuser");

        assertThat(response.getStatus()).isEqualTo(AccountStatus.CLOSED);
    }
}
