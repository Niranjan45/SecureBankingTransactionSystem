package com.banking.service;

import com.banking.dto.request.DepositWithdrawRequest;
import com.banking.dto.request.TransferRequest;
import com.banking.dto.response.TransactionResponse;
import com.banking.entity.*;
import com.banking.exception.*;
import com.banking.repository.AccountRepository;
import com.banking.repository.TransactionRepository;
import com.banking.repository.UserRepository;
import com.banking.service.impl.TransactionServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("TransactionService Unit Tests")
class TransactionServiceTest {

    @Mock private TransactionRepository transactionRepository;
    @Mock private AccountRepository accountRepository;
    @Mock private UserRepository userRepository;
    @Mock private RedisTemplate<String, Object> redisTemplate;
    @Mock private ValueOperations<String, Object> valueOperations;

    @InjectMocks
    private TransactionServiceImpl transactionService;

    private User user;
    private Account sourceAccount;
    private Account destinationAccount;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(transactionService, "maxTransferAmount",
                new BigDecimal("100000.00"));
        ReflectionTestUtils.setField(transactionService, "dailyTransferLimit",
                new BigDecimal("500000.00"));

        user = buildUser();
        sourceAccount = buildAccount("BNK000000000001", new BigDecimal("10000.00"), user);
        destinationAccount = buildAccount("BNK000000000002", new BigDecimal("5000.00"), buildOtherUser());
    }

    // ── Transfer ─────────────────────────────────────────────────────────────

    @Test
    @DisplayName("transfer: success with sufficient funds")
    void transfer_success() {
        TransferRequest request = buildTransferRequest("BNK000000000001", "BNK000000000002",
                new BigDecimal("1000.00"));

        setupRedisLock(true);
        when(accountRepository.findByAccountNumberWithLock("BNK000000000001"))
                .thenReturn(Optional.of(sourceAccount));
        when(accountRepository.findByAccountNumberWithLock("BNK000000000002"))
                .thenReturn(Optional.of(destinationAccount));
        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));
        when(transactionRepository.sumOutgoingTransactionsSince(any(), any()))
                .thenReturn(BigDecimal.ZERO);
        when(transactionRepository.save(any())).thenAnswer(i -> {
            Transaction t = i.getArgument(0);
            t.setId(1L);
            return t;
        });

        TransactionResponse response = transactionService.transfer(request, "testuser");

        assertThat(response).isNotNull();
        assertThat(response.getStatus()).isEqualTo(TransactionStatus.COMPLETED);
        assertThat(sourceAccount.getBalance()).isEqualByComparingTo("9000.00");
        assertThat(destinationAccount.getBalance()).isEqualByComparingTo("6000.00");
        verify(accountRepository, times(2)).save(any(Account.class));
    }

    @Test
    @DisplayName("transfer: throws InsufficientFundsException when balance too low")
    void transfer_insufficientFunds_throwsException() {
        TransferRequest request = buildTransferRequest("BNK000000000001", "BNK000000000002",
                new BigDecimal("50000.00"));

        setupRedisLock(true);
        when(accountRepository.findByAccountNumberWithLock("BNK000000000001"))
                .thenReturn(Optional.of(sourceAccount));
        when(accountRepository.findByAccountNumberWithLock("BNK000000000002"))
                .thenReturn(Optional.of(destinationAccount));
        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));
        when(transactionRepository.sumOutgoingTransactionsSince(any(), any()))
                .thenReturn(BigDecimal.ZERO);

        assertThatThrownBy(() -> transactionService.transfer(request, "testuser"))
                .isInstanceOf(InsufficientFundsException.class);
    }

    @Test
    @DisplayName("transfer: throws BankingException for self-transfer")
    void transfer_selfTransfer_throwsException() {
        TransferRequest request = buildTransferRequest(
                "BNK000000000001", "BNK000000000001", new BigDecimal("100.00"));

        assertThatThrownBy(() -> transactionService.transfer(request, "testuser"))
                .isInstanceOf(BankingException.class)
                .hasMessageContaining("same");
    }

    @Test
    @DisplayName("transfer: throws BankingException when Redis lock is taken")
    void transfer_concurrentLock_throwsException() {
        TransferRequest request = buildTransferRequest("BNK000000000001", "BNK000000000002",
                new BigDecimal("100.00"));
        setupRedisLock(false);

        assertThatThrownBy(() -> transactionService.transfer(request, "testuser"))
                .isInstanceOf(BankingException.class)
                .hasMessageContaining("concurrent");
    }

    @Test
    @DisplayName("transfer: throws AccountNotActiveException for suspended source account")
    void transfer_suspendedSourceAccount_throwsException() {
        sourceAccount.setStatus(AccountStatus.SUSPENDED);
        TransferRequest request = buildTransferRequest("BNK000000000001", "BNK000000000002",
                new BigDecimal("100.00"));

        setupRedisLock(true);
        when(accountRepository.findByAccountNumberWithLock("BNK000000000001"))
                .thenReturn(Optional.of(sourceAccount));
        when(accountRepository.findByAccountNumberWithLock("BNK000000000002"))
                .thenReturn(Optional.of(destinationAccount));
        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));
        when(transactionRepository.sumOutgoingTransactionsSince(any(), any()))
                .thenReturn(BigDecimal.ZERO);

        assertThatThrownBy(() -> transactionService.transfer(request, "testuser"))
                .isInstanceOf(AccountNotActiveException.class);
    }

    @Test
    @DisplayName("transfer: throws DailyLimitExceededException when daily cap reached")
    void transfer_dailyLimitExceeded_throwsException() {
        TransferRequest request = buildTransferRequest("BNK000000000001", "BNK000000000002",
                new BigDecimal("1000.00"));

        setupRedisLock(true);
        when(accountRepository.findByAccountNumberWithLock("BNK000000000001"))
                .thenReturn(Optional.of(sourceAccount));
        when(accountRepository.findByAccountNumberWithLock("BNK000000000002"))
                .thenReturn(Optional.of(destinationAccount));
        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));
        // Already spent 499,500 today
        when(transactionRepository.sumOutgoingTransactionsSince(any(), any()))
                .thenReturn(new BigDecimal("499500.00"));

        assertThatThrownBy(() -> transactionService.transfer(request, "testuser"))
                .isInstanceOf(DailyLimitExceededException.class);
    }

    // ── Deposit ───────────────────────────────────────────────────────────────

    @Test
    @DisplayName("deposit: success adds amount to balance")
    void deposit_success() {
        DepositWithdrawRequest request = new DepositWithdrawRequest();
        request.setAccountNumber("BNK000000000001");
        request.setAmount(new BigDecimal("2000.00"));

        when(accountRepository.findByAccountNumberWithLock("BNK000000000001"))
                .thenReturn(Optional.of(sourceAccount));
        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));
        when(transactionRepository.save(any())).thenAnswer(i -> {
            Transaction t = i.getArgument(0);
            t.setId(2L);
            return t;
        });

        TransactionResponse response = transactionService.deposit(request, "testuser");

        assertThat(response.getStatus()).isEqualTo(TransactionStatus.COMPLETED);
        assertThat(sourceAccount.getBalance()).isEqualByComparingTo("12000.00");
    }

    // ── Withdraw ──────────────────────────────────────────────────────────────

    @Test
    @DisplayName("withdraw: success deducts amount from balance")
    void withdraw_success() {
        DepositWithdrawRequest request = new DepositWithdrawRequest();
        request.setAccountNumber("BNK000000000001");
        request.setAmount(new BigDecimal("500.00"));

        when(accountRepository.findByAccountNumberWithLock("BNK000000000001"))
                .thenReturn(Optional.of(sourceAccount));
        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));
        when(transactionRepository.save(any())).thenAnswer(i -> {
            Transaction t = i.getArgument(0);
            t.setId(3L);
            return t;
        });

        TransactionResponse response = transactionService.withdraw(request, "testuser");

        assertThat(response.getStatus()).isEqualTo(TransactionStatus.COMPLETED);
        assertThat(sourceAccount.getBalance()).isEqualByComparingTo("9500.00");
    }

    @Test
    @DisplayName("withdraw: throws InsufficientFundsException when balance too low")
    void withdraw_insufficientFunds() {
        DepositWithdrawRequest request = new DepositWithdrawRequest();
        request.setAccountNumber("BNK000000000001");
        request.setAmount(new BigDecimal("99999.00"));

        when(accountRepository.findByAccountNumberWithLock("BNK000000000001"))
                .thenReturn(Optional.of(sourceAccount));
        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));

        assertThatThrownBy(() -> transactionService.withdraw(request, "testuser"))
                .isInstanceOf(InsufficientFundsException.class);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void setupRedisLock(boolean acquired) {
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.setIfAbsent(anyString(), any(), anyLong(), any(TimeUnit.class)))
                .thenReturn(acquired);
        if (acquired) {
            when(redisTemplate.delete(anyString())).thenReturn(true);
        }
    }

    private TransferRequest buildTransferRequest(String src, String dst, BigDecimal amount) {
        TransferRequest r = new TransferRequest();
        r.setSourceAccountNumber(src);
        r.setDestinationAccountNumber(dst);
        r.setAmount(amount);
        r.setDescription("Test transfer");
        return r;
    }

    private User buildUser() {
        return User.builder()
                .id(1L).username("testuser")
                .email("test@example.com").password("pass")
                .fullName("Test User").role(Role.ROLE_USER)
                .enabled(true).build();
    }

    private User buildOtherUser() {
        return User.builder()
                .id(2L).username("otheruser")
                .email("other@example.com").password("pass")
                .fullName("Other User").role(Role.ROLE_USER)
                .enabled(true).build();
    }

    private Account buildAccount(String number, BigDecimal balance, User owner) {
        return Account.builder()
                .id(number.endsWith("1") ? 1L : 2L)
                .accountNumber(number)
                .accountType(AccountType.SAVINGS)
                .balance(balance)
                .currency("INR")
                .status(AccountStatus.ACTIVE)
                .user(owner)
                .version(0L)
                .build();
    }
}
